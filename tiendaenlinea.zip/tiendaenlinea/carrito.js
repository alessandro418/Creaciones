const carritoContainer = document.querySelector('.carrito_container');
const totalElement = document.getElementById('total_compra');

function obtenerCarrito() {
    const carrito = localStorage.getItem('carrito');
    return carrito ? JSON.parse(carrito) : [];
}

function guardarCarrito(carrito) {
    localStorage.setItem('carrito', JSON.stringify(carrito));
}

function actualizarCarrito() {
    const carrito = obtenerCarrito();
    carritoContainer.innerHTML = '';
    let total = 0;

    carrito.forEach(item => {
        const div = document.createElement('div');
        div.className = 'item_carrito';
        div.innerHTML = `
            <img src="${item.imagen}" alt="Producto" style="width: 150px; height: 150px; margin: 10px; color: #000000;" />
        `;
        carritoContainer.appendChild(div);
        total += item.precio;
    });

    totalElement.textContent = Total: $${total.toFixed(2)};
}

// Función para agregar al carrito
function añadirAlCarrito(event) {
    const boton = event.target;
    const imagen = boton.getAttribute('data-imagen');
    const precio = parseFloat(boton.getAttribute('data-precio'));

    const carrito = obtenerCarrito();
    carrito.push({ imagen, precio });
    guardarCarrito(carrito);
    actualizarCarrito();
}

// Función para vaciar el carrito
function vaciarCarrito() {
    localStorage.removeItem('carrito');
    actualizarCarrito();
}

// Inicializar el carrito al cargar la página
document.addEventListener('DOMContentLoaded', () => {
    actualizarCarrito();

    // Agregar eventos a los botones de agregar al carrito
    document.querySelectorAll('.botondos').forEach(boton => {
        boton.addEventListener('click', añadirAlCarrito);
    });
});