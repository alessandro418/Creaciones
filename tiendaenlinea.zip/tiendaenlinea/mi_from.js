const botonComprar = document.querySelector('.boton_comprar');
const formularioCompra = document.getElementById('formularioCompra');
const botonCerrar = document.getElementById('botonCerrar');
const formCompra = document.getElementById('formCompra');

botonComprar.addEventListener('click', () => {
    formularioCompra.style.display = 'block';
});

botonCerrar.addEventListener('click', () => {
    formularioCompra.style.display = 'none';
});

formCompra.addEventListener('submit', (event) => {
    event.preventDefault(); // Evita el envío del formulario
    // Aquí puedes agregar la lógica para procesar la compra

    alert('Compra realizada con éxito');
    formularioCompra.style.display = 'none'; // Oculta el formulario
});

botonComprar.addEventListener('click', () => {
    const carrito = obtenerCarrito(); // Obtiene el carrito

    if (carrito.length === 0) {
        alert('El carrito está vacío. Añade productos antes de comprar.');
        formularioCompra.style.display = 'none';
    } else {
        formularioCompra.style.display = 'block'; // Muestra el formulario si hay elementos en el carrito
    }
});


formCompra.addEventListener('submit', (event) => {
    event.preventDefault(); // Evita el envío del formulario

    const nombre = document.getElementById('nombre').value;
    const apellido = document.getElementById('apellido').value;
    const direccion = document.getElementById('direccion').value;
    const metodoPago = document.getElementById('metodoPago').value;

    const carrito = obtenerCarrito(); // Obtén el carrito

    // Crea un objeto con la información de la compra
    const compra = {
        cliente: {
            nombre,
            apellido,
            direccion,
            metodoPago,
        },
        items: carrito,
    };

    // Aquí puedes enviar compra a un servidor o procesarlo como desees
    console.log('Información de compra:', compra);
});